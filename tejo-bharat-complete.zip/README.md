# Tejo Bharat - Complete Code
## తేజో భారత్ - పూర్తి కోడ్

This is the complete standalone code for tejobharath.in

### 📁 Files Included
- `index.html` - Main website (9.7MB, all-in-one, no external dependencies needed)
- `README.md` - This file
- `package.json` - For npm deployment (optional)
- `vercel.json` - Vercel config
- `netlify.toml` - Netlify config
- `.nojekyll` - GitHub Pages fix
- `CNAME.example` - Custom domain example
- `src/` - Extracted source code parts for reference

### 🚀 Deployment

#### GitHub Pages (Recommended)
1. Create repo: `tejo-bharat` on GitHub
2. Upload `index.html` as `index.html` (rename)
3. Settings > Pages > Source: main branch / root
4. Live at: https://YOUR_USERNAME.github.io/tejo-bharat/
5. Custom domain: Settings > Pages > Custom domain: tejobharath.in

#### Vercel
```bash
npm i -g vercel
vercel --prod
# Drag index.html
```

#### Netlify
- Go to app.netlify.com/drop
- Drag index.html

### 💻 Complete Code Structure

This `index.html` contains ALL code:

1. **HTML Structure**
   - Header with logo Pe (circular)
   - Hero slider #home with 4 images: lu, pu, qu, Lf (Tailoring, Medicines, Education, Farmer) - object-position center 15% to show top logo
   - Founder section #founder with fX image (Telugu Torch Logo circular, contain white bg) - TORCH BEARER badge hidden
   - Pillars #gallery, Heroes #heroes, Gallery #upload-gallery, Campaign #campaign, Join #join
   - Footer with WhatsApp +91 90329 00776

2. **CSS (Inside <style> tags)**
   - hero-logo-visible-fix-v2: object-position center 15% / 10% mobile / top small mobile - shows embedded logo
   - tejo-mobile-no-black-space: hero image cover center 35%
   - founder-logo-final-fix: founder img object-position 62% 8% / contain white
   - founder-logo-circular-fix: contain white padding 20px
   - TailwindCSS via CDN (inter, Noto Sans Telugu fonts)
   - Animations: marquee, hero-gradient

3. **JavaScript (Inside <script type="module">)**
   - React bundled (minified)
   - Hero slides: dr=[{img:lu},{img:pu},{img:qu},{img:Lf}] with badgeEn, titleEn/Te, subEn/Te, liveEn/Te
   - Founder: fX variable (base64 circular logo)
   - Gallery: [lu,pu,qu,Lf,uu,Vu,vu,Xu] mapped to Yatra Moments
   - Admin logic:
     ```js
     const ADMIN_PASSWORD = "AP16EJ0782@Ram";
     placeholder="Enter admin password" (hidden, not visible)
     localStorage tejo_admin_auth, tejo_gallery_images
     ```
   - Join popup: tejo-join-overlay with WhatsApp wa.me/919032900776
   - Language toggle: EN/TE
   - Sync hero background: syncHeroBackground()

4. **Embedded Assets (Base64)**
   - var uu, Vu, vu, rX, tX, lu, pu, qu, Lf, Xu, fX, Pe = "data:image/jpeg;base64,..."
   - lu=Tailoring, pu=Free Medicines, qu=Education, Lf=Farmer Training, fX=Circular Logo
   - Total 8+ images embedded

5. **Features**
   - Responsive: mobile logo left-shift, min-height 520px
   - Telugu translation toggle
   - Drag & Drop gallery upload
   - Admin password protected campaign pics

### 🔐 Admin
- Button: Bottom-right "🔐 అడ్మిన్ - Campaign Pics"
- Password: AP16EJ0782@Ram
- Placeholder: "Enter admin password" (hidden from public)

### 📱 Mobile Fixes Applied
- Hero logo visible: center top not 88% right
- Founder logo: contain white bg so full circle visible
- No black space on mobile

### 🛠️ To Edit Code
- Open index.html in VS Code
- Search var fX for founder photo
- Search var lu,pu,qu,Lf for hero images
- Search ADMIN_PASSWORD for password
- Search placeholder for password hint

### 📄 License
© 2026 Tejo Bharat - People First

---
Built with: React + Tailwind + Standalone HTML
Deploy: GitHub Pages / Vercel / Netlify
Contact: WhatsApp +91 90329 00776
