# Code Variables Reference

## Image Variables (Base64 embedded)
- var lu = Tailoring Training (105509.jpg) - Hero 1
- var pu = Free Medicines (105500.jpg) - Hero 2
- var qu = Education Support (102540) - Hero 3
- var Lf = Farmer Training (104535.jpg) - Hero 4
- var fX = Founder photo - NOW Circular Telugu Torch Logo (Telugu_Torch_Logo)
- var Pe = Header logo
- var uu, Vu, vu, Xu, rX, tX = Gallery images

## Hero Slides Array
dr=[{img:lu,badgeEn:"Vijayawada Yatra"},{img:pu,badgeEn:"Rural Assembly"},{img:qu,badgeEn:"Jan Jagaran"},{img:Lf,badgeEn:"Night Rally"}]

## Founder
src:fX, alt:"Rambabu Inaparti"
TORCH BEARER badge hidden via className:"hidden"

## Admin
const ADMIN_PASSWORD = "AP16EJ0782@Ram"
placeholder="Enter admin password" (was Password: AP16EJ0782@Ram - now hidden)

## Fixes Applied
- hero-logo-visible-fix-v2: center 15% not 88% right
- founder-logo-final-fix: 62% 8% + contain white
- tejo-mobile-no-black-space: cover center 35%
- min-height 520px

Total embedded images: 16
HTML size: 9720180 bytes
